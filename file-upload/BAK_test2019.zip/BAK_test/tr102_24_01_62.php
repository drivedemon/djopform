<?php

include("../lib/session.php");
include("../lib/config.php");
include("../lib/dbconnect.php");
include("../lib/function.php");
include("../lib/SiXhEaD.Template.php");
include("config.php");

include("../module/topbar_info.php"); // Top bar info

$formDataAction = 'ajax_save.php';
/* echo $_GET['id']."<br>";
echo $_GET['jvn_id']; */
if($_GET['row']!=""){
	$nid=$_GET['jvn_id'];
}
//-- html Template
$rootFile = currentFile();
$rootName = basename($rootFile, '.php');
$tp = new Template('templates/' . $rootName . '_tp.html');
//echo $rootFile;
//$sql = "SELECT j.*, TO_CHAR(j.WJVN_BIRTHDATE, 'dd/mm/yyyy', ' NLS_DATE_LANGUAGE=AMERICAN') AS BIRTHDATE_EN FROM "._JUVENILE_." j WHERE WC_ID='$nid' ";
$sql = "SELECT j.PARENTS_RELATION  FROM " . _JUVENILE_ . " j WHERE JVN_ID='$nid' ";
$stid = oci_parse($sysCont, $sql);
oci_execute($stid);
$rowP = oci_fetch_assoc($stid);
$ParentID = $rowP['PARENTS_RELATION'];

//$sqlParent="select  j.* from "._JUVENILE_." j where jvn_id='$nid' ";
$sqlParent = "select  ct.event_date,j.* from " . _JUVENILE_ . " j join cm_catchbook ct on ct.c_id=j.c_id where j.c_id=(select max(c_id) from tr_juvenile where  jvn_id='$nid')";
//echo $sqlParent;
$execParent = ociparse($sysCont, $sqlParent);
ociexecute($execParent);
$row = oci_fetch_assoc($execParent);

$fullName = getPrename($row['JVN_TITLENAME'], $sysCont) . ' ' . $row['JVN_NAME'] . ' ' . $row['JVN_SURNAME'];
//echo "+++++>".$row['WJVN_ID'];
//Image
$picture = getPicture($row['JVN_ID']);
if (empty($picture))
    $picture = '../images/userProfile.jpg';


$WJVN_SEX = $sysSex[strtoupper($row['JVN_SEX'])];
$WJVN_IDCARD = setFormatIDCard($row['JVN_IDCARD']);
$WJVN_BIRTHDATE = mod_dateThaiShort2($row['JVN_BIRTHDATE']);

$DateNow = date("Y/m/d");
$BirthDate = $row['JVN_BIRTHDATE'];
$Event_Date = $row['EVENT_DATE'];

$aAge = explode('-', ageNow($row['JVN_BIRTHDATE']));
$ageYear = $aAge[0];
$ageMonth = $aAge[1];
$ageDay = $aAge[2];


$WJVN_RACE = getRaceNationality($row['JVN_RACE']);
$WJVN_NATIONALITY = getRaceNationality($row['JVN_NATIONALITY']);
$WJVN_RELIGION = $row['JVN_RELIGION'];
//echo ">>>>$WJVN_RELIGION";
//�������Ѩ�غѹ
$WLIVE_AMPHUR = getAmphur($row['LIVE_PROVINCE'], $row['LIVE_AMPHUR']);
$WLIVE_PROVINCE = getProvince($row['LIVE_PROVINCE']);
$aWLIVE = getDistrict($row['LIVE_PROVINCE'], $row['LIVE_AMPHUR'], $row['LIVE_DISTRICT']); //�Ӻ�, ������ɳ���
//��������黡��ͧ
//if($ParentID=="01"){
$F_Fullname = getPrename($row['FATHER_TITLENAME'], $sysCont) . ' ' . $row['FATHER_NAME'] . ' ' . $row['FATHER_SURNAME'];
$F_Hno = $row['FATHER_HOUSE_NO'];
$F_Soi = $row['FATHER_SOI'];
$F_Road = $row['FATHER_ROAD'];
$F_Aphur = getAmphur($row['FATHER_PROVINCE'], $row['FATHER_AMPHUR']);
$F_Province = getProvince($row['FATHER_PROVINCE']);
$aFather = getDistrict($row['FATHER_PROVINCE'], $row['FATHER_AMPHUR'], $row['FATHER_DISTRICT']);
$F_District = $aFather['DIST_NAME'];
$F_Zipcode = $aFather['ZIP_CODE'];
//$F_Phone=$row['RULER_TELEPHONE'];
//}else if($ParentID=="02"){
$M_Fullname = getPrename($row['MOTHER_TITLENAME'], $sysCont) . ' ' . $row['MOTHER_NAME'] . ' ' . $row['MOTHER_SURNAME'];
$M_Hno = $row['MOTHER_HOUSE_NO'];
$M_Soi = $row['MOTHER_SOI'];
$M_Road = $row['MOTHER_ROAD'];
$M_Aphur = getAmphur($row['MOTHER_PROVINCE'], $row['MOTHER_AMPHUR']);
$M_Province = getProvince($row['MOTHER_PROVINCE']);
$aMother = getDistrict($row['MOTHER_PROVINCE'], $row['MOTHER_AMPHUR'], $row['MOTHER_DISTRICT']);
$M_District = $aMother['DIST_NAME'];
$M_Zipcode = $aMother['ZIP_CODE'];
//$M_Phone=$row['RULER_TELEPHONE'];
//}else if($ParentID=="06"){
$RULLER_Fullname = getPrename($row['RULER_TITLENAME'], $sysCont) . ' ' . $row['RULER_NAME'] . ' ' . $row['RULER_SURNAME'];
$RULLER_Hno = $row['RULER_HOUSE_NO'];
$RULLER_Soi = $row['RULER_SOI'];
$RULLER_Road = $row['RULER_ROAD'];
$RULLER_Aphur = getAmphur($row['RULER_PROVINCE'], $row['RULER_AMPHUR']);
$RULLER_Province = getProvince($row['RULER_PROVINCE']);
$aRULLER = getDistrict($row['RULER_PROVINCE'], $row['RULER_AMPHUR'], $row['RULER_DISTRICT']);
$RULLER_District = $aRULLER['DIST_NAME'];
$RULLER_Zipcode = $aRULLER['ZIP_CODE'];
$RULLER_Phone = $row['RULER_TELEPHONE'];
//}
//����ѵԤ��
$tp->block("DATA");
//$sql = "SELECT jdw.word_desc,ctrl.*, jud.* FROM TR_CONTROL_PLACE ctrl
/*$sql = "SELECT distinct(ctrl.redcasenum), ctrl.blackcasenum, ctrl.allegation_desc, jdw.word_desc, j.jvn_allegation, al.allegation_name, off.offense_code, off.offense_name, ctrl.unit_id_cm, jud.* 
FROM TR_CONTROL_PLACE ctrl
inner join tr_juvenile j on ctrl.jvn_id = j.jvn_id
left join md_allegation al on j.jvn_allegation = al.allegation_code
left join md_offense off on al.offense_code = off.offense_code
left join TR_judgment jud on ctrl.c_id=jud.c_id
left join md_judgment_word jdw on jud.judgment_word=jdw.word_id 
WHERE ctrl.JVN_ID='$row[JVN_ID]' "; */


$sql = " select ";
$sql.= " ctrl.c_id, ctrl.jvn_id, ctrl.redcasenum, ctrl.blackcasenum, ctrl.allegation_desc, ";
$sql.= " jdw.word_desc, j.jvn_allegation, ";
$sql.= " al.allegation_name,jud.PRACTICE_NOTE, ";
$sql.= " offense.offense_code, offense.offense_name, ";
$sql.= " ctrl.unit_id_cm, ctrl.send_date,ctrl.case_num, ";
$sql.= " jud.judgment_date, jud.practice_normal_begin, ";
$sql.= " jud.practice_normal_day, jud.practice_normal_month, jud.practice_normal_year, ";
$sql.= " jud.practice_max_day, jud.practice_max_month, jud.practice_max_year, ";
$sql.= " jud.practice_add_day, jud.practice_add_month, jud.practice_add_year, ";
$sql.= " jud.practice_minus_day, jud.practice_minus_month, jud.practice_minus_year, jud.PRACTICE_MIN_END, jud.PRACTICE_MAX_END ";
$sql.= " from tr_control_place ctrl ";
$sql.= " left join tr_judgment jud on ctrl.c_id = jud.c_id ";
$sql.= " left join md_judgment_word jdw on jud.judgment_word=jdw.word_id ";
$sql.= " left join tr_juvenile j on j.c_id = ctrl.c_id ";
$sql.= " left join md_allegation al on j.jvn_allegation = al.allegation_code ";
$sql.= " left join md_offense offense on al.offense_code = offense.offense_code ";
$sql.= " where ctrl.jvn_id ='" . $row[JVN_ID] . "'"; 

//echo $sql;
$stid2 = oci_parse($sysCont, $sql);
oci_execute($stid2);

$sql1 = " select ";
$sql1.= " count(ctrl.c_id) as ROW_1 ";
$sql1.= " from tr_control_place ctrl ";
$sql1.= " left join tr_judgment jud on ctrl.c_id = jud.c_id ";
$sql1.= " left join md_judgment_word jdw on jud.judgment_word=jdw.word_id ";
$sql1.= " left join tr_juvenile j on j.c_id = ctrl.c_id ";
$sql1.= " left join md_allegation al on j.jvn_allegation = al.allegation_code ";
$sql1.= " left join md_offense offense on al.offense_code = offense.offense_code ";
$sql1.= " where ctrl.jvn_id ='" . $row[JVN_ID] . "'"; 

//echo $sql;
$stid2_1 = oci_parse($sysCont, $sql1);
oci_execute($stid2_1);
while ($row2_1 = oci_fetch_assoc($stid2_1)) {	
	$count_row=$row2_1['ROW_1'];
	//echo $count_row;
}
$saveEnable = false;
$index = 1;
/*  */
$count_i=0;

if($_GET['row']=="T"){
	$c_id_send=$_GET['c_id'];
	//echo  $c_id_send;
	$sql_send="select PRACTICE_NORMAL_BEGIN from tr_judgment where C_ID=$c_id_send ";
	//$sql_send.="";
	//echo "<br>".$sql_send;
	$stid_send = oci_parse($sysCont, $sql_send);
	oci_execute($stid_send);
	$row5 = oci_fetch_assoc($stid_send);
	//echo "<br>".$row5['PRACTICE_NORMAL_BEGIN'];
	//
	$Date_BEGIN=$row5['PRACTICE_NORMAL_BEGIN'];
	//echo $Date_BEGIN;
	/* echo substr($Date_BEGIN,0,2);
	echo substr($Date_BEGIN,3,2);
	echo substr($Date_BEGIN,-4); */

	//echo "<br>".$Date_BEGIN."<br>";
	$chkCount=$_GET['count'];
	$chkInput=$_GET['chkInput'];	
/* 		function chkDate($day,$mon,$year,$amountDate){
			$minyear=$_GET['pracNormalYear'];
			$minmonth=$_GET['pracNormalMonth'];
			$minday=$_GET['pracNormalDay'];
			
			$addyear=$_GET['pracAddYear'];
			$addmonth=$_GET['pracAddMonth'];
			$addday=$_GET['pracAddDay'];
			
			$minusyear=$_GET['pracMinusYear'];
			$minusmonth=$_GET['pracMinusMonth'];
			$minusday=$_GET['pracMinusDay'];
		
			//����᷹��һ�Ѻ
				if($addday!="0"){
					$day=$day+$addday;
					if($day>=$amountDate){
						$day=$day-$amountDate;
						$mon=$mon+1;
					}
					//echo $day;
				}
				if($addmonth!=0){
					$mon=$mon+$addmonth;
				}
				if($addyear!=0){
					$year=$year+$addyear;
				}
				//�ѡ�ѹ�Ǻ������
				if($minusday!="0"){
					//$day=$day+$minusday;
					//intval($strValue);
					echo intval($day)."<br>";
					$day=intval($day);
					echo $minusday."<br>";
					if($day<=$minusday){
						$count=$minusday/30;
						//echo $count."<br>";
						echo round($count)."<br>";
						//$count1=round($count);
						//echo $count1."<br>";
						$day=$minusday-$day;
						echo "day:".$day."<br>";
						for($i=0;$i<round($count);$i++){
							$mon=intval($mon)-1;
							if($mon=="0"){
								$mon="12";
								$year=$year-1;
							}
							if(strlen($mon)==1){
								$mon="0".$mon;
							}			
							if($mon=="01" || $mon=="03" || $mon=="05" || $mon=="07" || $mon=="08" || $mon=="10" || $mon=="12"){
								$day = $day-31;
							}
							if($mon=="04" || $mon=="06" || $mon=="09" || $mon=="11"){
								$day = $day-30;
							}
							if($mon=="02" && $year%4==0){
								$day = $day-29;
							}else if($mon=="02"){
								$day = $day-28;
							}
							$minusday=$day;
							echo "������� :".$minusday.":mon:".$mon.":year:".$year."<br>";
						}						
					}else{
						$day=$day-$minusday;
						//echo $day;
					}
					
				}
				if($minusmonth!=0){
					$mon=$mon-$minusmonth;
				}
				if($minusyear!=0){
					$year=$year-$minusyear;
				}
				//����µ�Ǣ�鹵��
				if($minday!=0){
					$day=$day+$minday;
					if($day>=31){
						$day=$day-31;
						$mon=$mon+1;
					}
				}
				if($minmonth!=0){
					$mon=$mon+$minmonth;
				}
				if($minyear!=0){
					$year=$year+$minyear;
				}
				return $day."/".$mon."/".$year;
			} */
		
	//echo "<br>".$minyear."<br>".$minmonth."<br>".$minday."<br>";
		if($chkInput=="1"){
			$day=substr($Date_BEGIN,0,2);
			$mon=substr($Date_BEGIN,3,2);
			$year=substr($Date_BEGIN,-4);
			
			$minyear=$_GET['pracNormalYear'];
			$minmonth=$_GET['pracNormalMonth'];
			$minday=$_GET['pracNormalDay'];
			
			$addyear=$_GET['pracAddYear'];
			$addmonth=$_GET['pracAddMonth'];
			$addday=$_GET['pracAddDay'];
			
			$minusyear=$_GET['pracMinusYear'];
			$minusmonth=$_GET['pracMinusMonth'];
			$minusday=$_GET['pracMinusDay'];
			
			$minShow = "";
			$minDate = "�ѧ������˹�";
			$min = null;

			
			$min = !is_null($min) ? $minDate : $Date_BEGIN;
			if(!is_null($_GET['pracAddDay']) && !is_null($_GET['pracAddMonth']) && !is_null($_GET['pracAddYear']) &&
			   !is_null($_GET['pracMinusDay']) && !is_null($_GET['pracMinusMonth']) && !is_null($_GET['pracMinusYear'])){
				$sumAddDays = $i==0 ? $_GET['pracAddDay']+$totalAddDay : $_GET['pracAddDay'];
				$sumSubDays = $i==0 ? $_GET['pracMinusDay']+$TotalSubDay : $_GET['pracMinusDay'];
				if ($_GET['pracNormalDay'] == 0 && $_GET['pracNormalMonth'] == 0 && $_GET['pracNormalYear'] == 0) {
					$maxShow = "�����";
				} else {
					$minDate = adjustCaseDate($min,
							$$_GET['pracNormalDay'],$_GET['pracNormalMonth'],$_GET['pracNormalYear'],
							$sumAddDays,$_GET['pracAddMonth'],$_GET['pracAddYear'],
							$sumSubDays,$_GET['pracMinusMonth'],$_GET['pracMinusYear']);
					$minShow = mod_dateThaiFull2($minDate);
					$Date_BEGIN=$minShow;
				}
			}else{
				$minShow = "�ѧ������˹�";
			}
			//echo $minShow."<br>";
			
		/* 	if($mon=="01" || $mon=="03" || $mon=="05" || $mon=="07" || $mon=="08" || $mon=="10" || $mon=="12"){
				//echo "31"."<br>";	
				$amountDate="31";
				//echo chkDate($day,$mon,$year,$amountDate);
				$Date_BEGIN=mod_dateThaiFull2(chkDate($day,$mon,$year,$amountDate));
				echo $Date_BEGIN;
				//echo $day."/".$mon."/".$year;
				}
			if($mon=="04" || $mon=="06" || $mon=="09" || $mon=="11"){
			
				//echo "30";
				$amountDate="30";
				$Date_BEGIN=mod_dateThaiFull2(chkDate($day,$mon,$year,$amountDate));
				echo $Date_BEGIN;
				//chkDate($day,$mon,$year,$amountDate);
				//echo $day."/".$mon."/".$year;
			}
			if($mon=="02" && $year%4==0){
				//echo "29";
				$amountDate="29";
				$Date_BEGIN=mod_dateThaiFull2(chkDate($day,$mon,$year,$amountDate));
				echo $Date_BEGIN;
				//chkDate($day,$mon,$year,$amountDate);
			}else if($mon=="02"){
				//echo "28";
				$amountDate="28";
				$Date_BEGIN=mod_dateThaiFull2(chkDate($day,$mon,$year,$amountDate));
				echo $Date_BEGIN;
				//chkDate($day,$mon,$year,$amountDate);
			}*/
		}else if($chkInput=="2"){
			$Date_BEGIN=mod_dateThaiFull2($row5['PRACTICE_NORMAL_BEGIN']);
		} 
		//}
	}
	//echo $chkCount;

while ($row2 = oci_fetch_assoc($stid2)) {
    $rnd = 'bb' . rand(1, 9999);
	$count_i++;
	if($_GET['status']==1){
		for($a=1;$a<=$count_row;$a++){
			if($_GET['row']==$a){
				echo $a."<br>";
			}
		}		
	}else if($_GET['status']==2){
		for($a=1;$a<=$count_row;$a++){
			if($_GET['row']==$a){
				echo $a;
			}
		}
	}
	$arr[$count_i-1]=$count_i;
	//echo $arr[$count_i-1]."<br>";
	
/* 	foreach($arr as $names){ //�Ӥ������ form element"
	echo "<input type='text' name='count1[]' value='".$names."'>";
	} */
	//$name="count".$count_i;
	$name="count";
	$text="text".$count_i;
	//echo $name;
	//$test="<form name='frm1' action='' method='post'>";
	$test="<input type='checkbox' name='".$name."' id='".$name."' value='$count_i'/>���͡<br>";
	//$test.="�Ѻ��� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;���&nbsp;<input type='text' name='input.'".$count_i."'' id='input.'".$count_i."'' style='width:40px;'/><br>";
	//$test.="(�Ѻ��� ��� 1 ���� �Ѻ������ѹ ��� 2)<br><input type='text' name='input' id='input' style='width:40px;'/>&nbsp;&nbsp;";
	$test.="�Ѻ���&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;�ҡ���<input type='text' name='input1' id='input1' style='width:40px;'/><br>";
	$test.="�Ѻ������ѹ&nbsp;&nbsp;�ҡ���<input type='text' name='input2' id='input2' style='width:40px;'/><br>";
	//$test.="<input type='checkbox' name='".$name."' id='".$name."' value='$count_i'/>";
	//$test.="�Ѻ������ѹ&nbsp;���&nbsp;<input type='text' name='input.'".($count_i+1)."'' id='input.'".($count_i+1)."'' style='width:40px;'/><br>";
	$test.="<input type='hidden' name='chk1' id='chk1' value='".$count_i."'/>";
	$test.="<input type='hidden' name='chk2' id='chk2' value='".$count_row."'/>";
	//$test.="<input type='button' name='Send1' id='Send1' value='��ŧ' onclick='check1();' />&nbsp;<br>";
	//$test.="<input type='button' name='cancel1' id='cancel1' value='¡��ԡ' onclick='check1();' /> <br>";
	//$test.="</form>";
	

	
    //�Ѻ���ѹ���
	//echo $row2['PRACTICE_NORMAL_BEGIN']."<br>";
	//echo $row2['PRACTICE_NORMAL_MONTH']."<br>";
    $pracNormalBegin = mod_dateThaiFull2($row2['PRACTICE_NORMAL_BEGIN']);
	if($count_i==$chkCount){
		//echo "<br>"."testcount"." ".$chkCount;
		$pracNormalBegin=$Date_BEGIN;
	}
	//$totalAddDay="0";
	//$TotalSubDay="0";
	$minShow = "";
	$maxShow = "";
	$minDate = "�ѧ������˹�";
	$maxDate = "�ѧ������˹�";
	$min = null;
	$max = null;
	$date_cal=$row2['PRACTICE_NORMAL_BEGIN'];
	//echo $date_cal." - ";
	$min = !is_null($min) ? $minDate : $date_cal;
	//echo $min." = ";
    if(!is_null($row2['PRACTICE_ADD_DAY']) && !is_null($row2['PRACTICE_ADD_MONTH']) && !is_null($row2['PRACTICE_ADD_YEAR']) &&
       !is_null($row2['PRACTICE_MINUS_DAY']) && !is_null($row2['PRACTICE_MINUS_MONTH']) && !is_null($row2['PRACTICE_MINUS_YEAR'])){
        $sumAddDays = $i==0 ? $row2['PRACTICE_ADD_DAY']+$totalAddDay : $row2['PRACTICE_ADD_DAY'];
        $sumSubDays = $i==0 ? $row2['PRACTICE_MINUS_DAY']+$TotalSubDay : $row2['PRACTICE_MINUS_DAY'];
		//echo $sumAddDays." | ".$sumSubDays."<br>";
		//echo $totalAddDay." ||| ".$TotalSubDay."<br>";
        if ($row2['PRACTICE_NORMAL_DAY'] == 0 && $row2['PRACTICE_NORMAL_MONTH'] == 0 && $row2['PRACTICE_NORMAL_YEAR'] == 0) {
            $minShow_Row = "�����";
        } else {
            $minDate = adjustCaseDate($min,
                    $row2['PRACTICE_NORMAL_DAY'],$row2['PRACTICE_NORMAL_MONTH'],$row2['PRACTICE_NORMAL_YEAR'],
                    $sumAddDays,$row2['PRACTICE_ADD_MONTH'],$row2['PRACTICE_ADD_YEAR'],
                    $sumSubDays,$row2['PRACTICE_MINUS_MONTH'],$row2['PRACTICE_MINUS_YEAR']);
            $minShow_Row = mod_dateThaiShort2($minDate);
			//echo $minDate."<br>";
			//$min = null;
        }
    }else{
        $minShow_Row = "�ѧ������˹�";
    }
//echo $row2['PRACTICE_NORMAL_BEGIN']."<br>";
    $max = !is_null($max) ? $maxDate : $row2['PRACTICE_NORMAL_BEGIN'];
    if(!is_null($row2['PRACTICE_ADD_DAY']) && !is_null($row2['PRACTICE_ADD_MONTH']) && !is_null($row2['PRACTICE_ADD_YEAR']) &&
       !is_null($row2['PRACTICE_MINUS_DAY']) && !is_null($row2['PRACTICE_MINUS_MONTH']) && !is_null($row2['PRACTICE_MINUS_YEAR'])){
        $sumAddDays = $i==0 ? $row2['PRACTICE_ADD_DAY']+$totalAddDay : $row2['PRACTICE_ADD_DAY'];
       $sumSubDays = $i==0 ? $row2['PRACTICE_MINUS_DAY']+$TotalSubDay : $row2['PRACTICE_MINUS_DAY'];
        if ($row2['PRACTICE_MAX_DAY'] == 0 && $row2['PRACTICE_MAX_MONTH'] == 0 && $row2['PRACTICE_MAX_YEAR'] == 0) {
            $maxShow_Row = "�����";
        } else {
            $maxDate = adjustCaseDate($max,
                    $row2['PRACTICE_MAX_DAY'],$row2['PRACTICE_MAX_MONTH'],$row2['PRACTICE_MAX_YEAR'],
                    $sumAddDays,$row2['PRACTICE_ADD_MONTH'],$row2['PRACTICE_ADD_YEAR'],
                    $sumSubDays,$row2['PRACTICE_MINUS_MONTH'],$row2['PRACTICE_MINUS_YEAR']);
            $maxShow_Row = mod_dateThaiShort2($maxDate);
			//echo $maxShow_Row;
			//$max = null;
        }
    }else{
        $maxShow_Row = "�ѧ������˹�";
    }

	
	
	//�ѹ�Ѻ���
	$sendDate = mod_dateThaiFull2($row2['SEND_DATE']);
	
    //�ѹ�����ŵѴ�Թ
    $judgmentDate = mod_dateThaiFull2($row2['JUDGMENT_DATE']);


    //�Ѵ�Թ��鹵��
    $pracNormalDay = $row2['PRACTICE_NORMAL_DAY'];
    $pracNormalMonth = $row2['PRACTICE_NORMAL_MONTH'];
    $pracNormalYear = $row2['PRACTICE_NORMAL_YEAR'];

    //�Ѵ�Թ����٧
    $pracMaxDay = $row2['PRACTICE_MAX_DAY'];
    $pracMaxMonth = $row2['PRACTICE_MAX_MONTH'];
    $pracMaxYear = $row2['PRACTICE_MAX_YEAR'];

    //��Ѻ�ѹ
    $pracAddDay = $row2['PRACTICE_ADD_DAY'];
    $pracAddMonth = $row2['PRACTICE_ADD_MONTH'];
    $pracAddYear = $row2['PRACTICE_ADD_YEAR'];

    //�ѡ�ѹ
    $pracMinusDay = $row2['PRACTICE_MINUS_DAY'];
    $pracMinusMonth = $row2['PRACTICE_MINUS_MONTH'];
    $pracMinusYear = $row2['PRACTICE_MINUS_YEAR'];
	
	$minimum = mod_dateThaiFull2($row2['PRACTICE_MIN_END']);
	$maximum = mod_dateThaiFull2($row2['PRACTICE_MAX_END']);
	
    $disable = '';
    $disabledStyle = '';
    if ($row2['PRACTICE_NORMAL_BEGIN'] != NULL && $pracNormalDay != NULL && $pracNormalMonth != NULL && $pracNormalYear != NULL && $pracMaxDay != NULL && $pracMaxMonth != NULL && $pracMaxYear != NULL && $pracAddDay != NULL && $pracAddMonth != NULL && $pracAddYear != NULL && $pracMinusDay != NULL && $pracMinusMonth != NULL && $pracMinusYear != NULL) {
       // $disable = 'disabled';
        $disabledStyle = 'display:none;';
		$saveEnable = true;
    }else{
        $saveEnable = true;
    }

    //����觽֡
    $WUNIT_ID_CM = getDivision($row2['UNIT_ID_CM']);

    //���͹䢡�ý֡ͺ��
    $pracNote = $row2['PRACTICE_NOTE'];
    //echo $pracNote."<br>";
    $tp->apply();
    $index++;
}

$showInstruction = '';
if($saveEnable == true){
    $btSave = 'onclick="toSave()" ';
    $dfSave = 'g_save.gif'; 
}else{
    $showInstruction = 'display:none;';
}

//�ŤӾԾҡ��
/* $sqlResult="select mdj.word_desc from tbl_TR_judgment jud,Tbl_TR_Control_Place ctrl,MD_JUDGMENT_WORD mdj
  where jud.wc_id=ctrl.wc_id and mdj.word_id=jud.wjudgment_word  and ctrl.wjvn_id='$row[WJVN_ID]'";
  $execResult=ociparse($sysCont,$sqlResult);
  ociexecute($execResult);
  $injResult=oci_fetch_assoc($execResult);
  $R_inj=$injResult['WORD_DESC']; */
//echo ">>>>>".$R_inj;
//echo ">>$sqlResult";
//�����Ż����Թ�Ǻ���
$sql = "SELECT * FROM TR_CONTROL_LEVEL WHERE JVN_ID='" . $row['JVN_ID'] . "' ";
$stid5 = oci_parse($sysCont, $sql);
oci_execute($stid5);
$rCtrlevel = oci_fetch_assoc($stid5);
//��ػ�ѭ�ҷ�辺
$ctrPrbm = $rCtrlevel['PROBLEMS'];
if ($rCtrlevel['HEALTH_STATUS'] == "1")
    $ctrPrbm .= ' �ѭ��������آ�Ҿ';
if ($rCtrlevel['OVERBEAR_STATUS'] == "1")
    $ctrPrbm .= ' �ѡɳз����µ�͡�ö١�ѧ� ����˧';
if ($rCtrlevel['DANGER_STATUS'] == "1")
    $ctrPrbm .= ' �������µ����/���Ǫ����';
if ($rCtrlevel['NOXIOUS_STATUS'] == "1")
    $ctrPrbm .= ' �������µ�͵��ͧ';
if ($rCtrlevel['ESCAPE_STATUS'] == "1")
    $ctrPrbm .= ' ����ź˹ըҡʶҹ�Ǻ���';

//�дѺ��äǺ�������
$ctrLevel = $rCtrlevel['CONTROL_LEVEL'];
if (!empty($rCtrlevel['CONTROL_LEVEL_STATUS']))
    $ctrLevel .= ' �� ' . $rCtrlevel['CONTROL_LEVEL_STATUS'];
if (!empty($rCtrlevel['CONTROL_LEVEL_DETAIL']))
    $ctrLevel .= ' ' . $rCtrlevel['CONTROL_LEVEL_DETAIL'];


//����������ѡ / ��˹� / ����
$Tattoo = getTattoo($row['JVN_ID']);

//�����Ŵ�ҹ������آ�Ҿ
$sql = "SELECT * FROM TR_HEALTH WHERE JVN_ID='" . $row['JVN_ID'] . "' ";
$stid4 = oci_parse($sysCont, $sql);
oci_execute($stid4);
$rHealth = oci_fetch_assoc($stid4);
if ($rHealth) {
    $WDOCTER_DATE = mod_dateThaiShort2($rHealth['DOCTER_DATE']);
    $WNURSE_DATE = mod_dateThaiShort2($rHealth['NURSE_DATE']);
    if ($rHealth['DOCTER_ANOMALY_STATUS'] == "1") { //�����Դ���Ԣͧ������آ�Ҿ
        //Query MD_ANOMALY  Type "D"
        $ANOMALY = "";
    }
    if ($rHealth['DOCTER_DISEASES_STATUS'] == "1") { //�ä��Шӵ��
        //Query MD_ANOMALY
        $DISEASES = "";
    }
    if (!empty($rHealth['DISABILITY_CODE'])) { //�����ԡ��
        //Query md_disability
        $DISABILITY = " " . $rHealth['DISABILITY_OTHER']; //�����ԡ������ͧᾷ��
    }
    if ($rHealth['NURSE_ANOMALY_STATUS'] == "1") { //��õ�Ǩ��ҧ��·�辺�����Դ����
        //Query MD_ANOMALY  Type "N"
        $nurseAnomaly = " " . $rHealth['NURSE_ANOMALY_OTHER']; //����
    }
    if (!empty($rHealth['ANOMALY_FORWARD'])) { //�����Դ���Է���ͧ���ŵ�����ͧ
        //Query MD_ANOMALY  Type "F"
        $wanomalyForward = " " . $rHealth['ANOMALY_FORWARD_OTHER']; //
    }
}


//�����Ŵ�ҹ�ѧ��ʧ������
$sql = "SELECT * FROM TR_SOCIAL WHERE JVN_ID='" . $row['JVN_ID'] . "' ";
$stid3 = oci_parse($sysCont, $sql);
oci_execute($stid3);
$rSocial = oci_fetch_assoc($stid3);
if ($rSocial) {
    if ($rSocial['PROBM_FAMILY_STATUS'] == "1") { //��ҹ��ͺ����
        //Query MD_SOCIAL_PROBM
        $pFAMILY = "";
    }
    if ($rSocial['PROBM_PERSON_STATUS'] == "1") { //��ҹ���͹��кؤ�����Դ 
        //Query MD_SOCIAL_PROBM
        $pPERSON = "";
    }
    if ($rSocial['PROBM_WELFARE_STATUS'] == "1") { //��ҹ��ä�����ͧ���ʴ��Ҿ 
        //Query MD_SOCIAL_PROBM
        $pWELFARE = "";
    }
    if ($rSocial['PROBM_TRADE_HUMAN_STATUS'] == "1") { //��ҹ��ä�������� 
        //Query MD_SOCIAL_PROBM
        $pHUMAN = "";
    }
    if ($rSocial['PROBM_SPECIAL_STATUS'] == "1") { //�óջѭ�Ҿ���� 
        //Query MD_SOCIAL_PROBM
        $pSPECIAL = "";
    }
    if ($rSocial['HELP_CONSUL_STATUS'] == "1") { //���ӻ�֡��
        //Query MD_SOCIAL_PROBM
        $pCONSUL = "";
    }
    if ($rSocial['HELP_RELIEF_STATUS'] == "1") { //�����ʧ������
        //Query MD_SOCIAL_PROBM
        $pRELIEF = "";
    }
    if ($rSocial['HELP_TREATMENT_STATUS'] == "1") { //�Ԩ�����ӺѴ੾�д�ҹ
        //Query MD_SOCIAL_PROBM
        $pTREATMENT = "";
    }
    if ($rSocial['HELP_COORDINAT_STATUS'] == "1") { //����ҹ�ҹ/�觵��
        //Query MD_SOCIAL_PROBM
        $pCOORDINAT = "";
    }
}

//�����š�õ�Ǩ�Ե�Է��
$sql = "SELECT * FROM TR_PSYCHOLOGY WHERE JVN_ID='" . $row['JVN_ID'] . "' ";
$stid5 = oci_parse($sysCont, $sql);
oci_execute($stid5);
$rPsycgy = oci_fetch_assoc($stid5);
if ($rPsycgy) {
    if (!empty($rPsycgy['INT_LEVEL_CODE'])) { //�дѺ����ѭ��
        $intelligence = getIntelligence($rPsycgy['INT_LEVEL_CODE']);
    }
    if (!empty($rPsycgy['ADAPTATION_CODE'])) { //��û�Ѻ���
        $adaptation = getAdaptation($rPsycgy['ADAPTATION_CODE']);
    }
}

$sqlcase = " SELECT jud.PRACTICE_NORMAL_BEGIN, jud.PRACTICE_NORMAL_DAY, jud.PRACTICE_NORMAL_MONTH, jud.PRACTICE_NORMAL_YEAR ";
$sqlcase.= " , jud.PRACTICE_MAX_DAY, jud.PRACTICE_MAX_MONTH, jud.PRACTICE_MAX_YEAR ";
$sqlcase.= " , jud.PRACTICE_ADD_DAY, jud.PRACTICE_ADD_MONTH, jud.PRACTICE_ADD_YEAR ";
$sqlcase.= " , jud.PRACTICE_MINUS_DAY, jud.PRACTICE_MINUS_MONTH, jud.PRACTICE_MINUS_YEAR";
$sqlcase.= " FROM TR_CONTROL_PLACE ctrl left join TR_JUDGMENT jud on ctrl.c_id=jud.c_id WHERE ctrl.JVN_ID ='" . $row['JVN_ID'] . "'";
$stidcase = oci_parse($sysCont, $sqlcase);
oci_execute($stidcase);

$i = 0;

$minShow = "";
$maxShow = "";
$minDate = "�ѧ������˹�";
$maxDate = "�ѧ������˹�";
$min = null;
$max = null;

while ($rowCase = oci_fetch_assoc($stidcase)) {
	//echo $rowCase['PRACTICE_NORMAL_BEGIN'];
    $min = !is_null($min) ? $minDate : $rowCase['PRACTICE_NORMAL_BEGIN'];
    if(!is_null($rowCase['PRACTICE_ADD_DAY']) && !is_null($rowCase['PRACTICE_ADD_MONTH']) && !is_null($rowCase['PRACTICE_ADD_YEAR']) &&
       !is_null($rowCase['PRACTICE_MINUS_DAY']) && !is_null($rowCase['PRACTICE_MINUS_MONTH']) && !is_null($rowCase['PRACTICE_MINUS_YEAR'])){
        $sumAddDays = $i==0 ? $rowCase['PRACTICE_ADD_DAY']+$totalAddDay : $rowCase['PRACTICE_ADD_DAY'];
        $sumSubDays = $i==0 ? $rowCase['PRACTICE_MINUS_DAY']+$TotalSubDay : $rowCase['PRACTICE_MINUS_DAY'];
        if ($rowCase['PRACTICE_NORMAL_DAY'] == 0 && $rowCase['PRACTICE_NORMAL_MONTH'] == 0 && $rowCase['PRACTICE_NORMAL_YEAR'] == 0) {
            $minShow = "�����";
        } else {
            $minDate = adjustCaseDate($min,
                    $rowCase['PRACTICE_NORMAL_DAY'],$rowCase['PRACTICE_NORMAL_MONTH'],$rowCase['PRACTICE_NORMAL_YEAR'],
                    $sumAddDays,$rowCase['PRACTICE_ADD_MONTH'],$rowCase['PRACTICE_ADD_YEAR'],
                    $sumSubDays,$rowCase['PRACTICE_MINUS_MONTH'],$rowCase['PRACTICE_MINUS_YEAR']);
            $minShow = mod_dateThaiShort2($minDate);
        }
    }else{
        $minShow = "�ѧ������˹�";
    }

    $max = !is_null($max) ? $maxDate : $rowCase['PRACTICE_NORMAL_BEGIN'];
	
    if(!is_null($rowCase['PRACTICE_ADD_DAY']) && !is_null($rowCase['PRACTICE_ADD_MONTH']) && !is_null($rowCase['PRACTICE_ADD_YEAR']) &&
       !is_null($rowCase['PRACTICE_MINUS_DAY']) && !is_null($rowCase['PRACTICE_MINUS_MONTH']) && !is_null($rowCase['PRACTICE_MINUS_YEAR'])){
        $sumAddDays = $i==0 ? $rowCase['PRACTICE_ADD_DAY']+$totalAddDay : $rowCase['PRACTICE_ADD_DAY'];
        $sumSubDays = $i==0 ? $rowCase['PRACTICE_MINUS_DAY']+$TotalSubDay : $rowCase['PRACTICE_MINUS_DAY'];
		//echo $sumAddDays."<br>".$sumSubDays;
        if ($rowCase['PRACTICE_MAX_DAY'] == 0 && $rowCase['PRACTICE_MAX_MONTH'] == 0 && $rowCase['PRACTICE_MAX_YEAR'] == 0) {
            $maxShow = "�����";
        } else {
            $maxDate = adjustCaseDate($max,
                    $rowCase['PRACTICE_MAX_DAY'],$rowCase['PRACTICE_MAX_MONTH'],$rowCase['PRACTICE_MAX_YEAR'],
                    $sumAddDays,$rowCase['PRACTICE_ADD_MONTH'],$rowCase['PRACTICE_ADD_YEAR'],
                    $sumSubDays,$rowCase['PRACTICE_MINUS_MONTH'],$rowCase['PRACTICE_MINUS_YEAR']);
					//echo $maxDate;
            $maxShow = mod_dateThaiShort2($maxDate);
        }
    }else{
        $maxShow = "�ѧ������˹�";
    }

    $i++;
}
//-- top icon menu
$btBack = 'onclick="toBackx(\'../mod_tr200/index.php\')" ';
$dfBack = 'g_back.gif';
//$btSave = 'onclick="toSave()" ';
//$dfSave = 'g_save.gif';
$clr = new Template('../module/icon_menutop_tp.html');
$iconControl = $clr->generate();

$tp->Display();
include("../lib/dbclose.php");
?>